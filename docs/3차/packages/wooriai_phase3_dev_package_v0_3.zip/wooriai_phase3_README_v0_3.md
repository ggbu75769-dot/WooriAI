# 우리아이 개발 고정 3차 산출물 v0.3

작성 기준일: 2026-07-05

## 포함 파일

- `wooriai_phase3_dev_fixed_docs_v0_3.docx`  
  데이터 모델, DB 설계서, API 정의서, 인증/권한 정책, 프로젝트 폴더 구조, 상태관리 설계서, 공통 컴포넌트 정의서가 포함된 통합 문서입니다.

- `wooriai_phase3_dev_tables_v0_3.xlsx`  
  데이터 모델/DB 컬럼/API/RBAC/상태관리/컴포넌트 관리용 스프레드시트입니다.

- `wooriai_phase3_schema_v0_3.sql`  
  PostgreSQL 15+ 기준 DDL, enum, index, view, seed category SQL입니다.

- `wooriai_phase3_openapi_v0_3.yaml`  
  OpenAPI 3.1 기준 REST API 명세입니다.

- `wooriai_phase3_project_structure_v0_3.md`  
  React Native + Expo / NestJS / Next.js Admin 기준 Monorepo 폴더 구조입니다.

- `wooriai_phase3_erd_v0_3.png` / `wooriai_phase3_erd_v0_3.mmd` / `wooriai_phase3_erd_v0_3.dot`  
  ERD 이미지와 원본 다이어그램 파일입니다.

- `wooriai_phase3_architecture_v0_3.png` / `wooriai_phase3_state_flow_v0_3.png`  
  시스템 아키텍처와 모바일 상태관리 흐름 이미지입니다.

## 개발 고정 결정

- 모바일: React Native + Expo + Expo Router
- 백엔드: NestJS + TypeScript
- DB/ORM: PostgreSQL 15+ + Prisma
- 상태관리: TanStack Query + Zustand + React Hook Form + Zod
- 관리자: Next.js Admin 또는 Retool 베타 후 Next.js 전환
- 파일/AI: S3 호환 스토리지 + Import Worker

## 주의

출시 전 개인정보, 아동 개인정보, 제휴/광고 표시, 의료성 표현은 최신 정책과 법무 검토가 필요합니다.
