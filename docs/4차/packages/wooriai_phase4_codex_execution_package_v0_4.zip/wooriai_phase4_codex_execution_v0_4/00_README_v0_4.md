# 우리아이 Phase 4 Codex Execution Package v0.4

작성 기준일: 2026-07-05

이 패키지는 Codex가 우리아이 MVP를 구현할 때 흔들리지 않도록 실행 지시, 구현 계획, 작업 분해, 변경 금지 계약, 수용 기준, QA 절차, 릴리즈 체크리스트를 고정한 문서입니다.

## 사용 순서
1. `01_codex_master_instruction_v0_4.md` 전체를 Codex의 상위 지시로 붙여넣습니다.
2. `04_do_not_change_v0_4.md`를 함께 제공해 변경 금지 계약을 고정합니다.
3. `02_implementation_plan_v0_4.md`에서 현재 단계의 Batch를 선택합니다.
4. `03_task_breakdown_v0_4.md` 또는 `wooriai_phase4_codex_execution_tables_v0_4.xlsx`에서 작업 ID를 지정합니다.
5. 각 실행 후 `05_acceptance_criteria_v0_4.md`, `06_qa_runbook_v0_4.md`로 검수합니다.
6. 배포 전 `07_release_checklist_v0_4.md`를 완료합니다.

## 고정 핵심
- 제품: 아이 비용 관리 + 시기별 준비템 구매 내비게이션
- 하단 탭: 홈 / 기록 / 준비템 / 리포트
- 스택: React Native + Expo, NestJS, PostgreSQL + Prisma, Next.js Admin
- 수익화: 제휴 링크/클릭 로그/투명한 고지. 추천 점수에 수수료율 직접 반영 금지
- 엑셀 업로드: 미리보기와 사용자 승인 전 expenses 저장 금지
